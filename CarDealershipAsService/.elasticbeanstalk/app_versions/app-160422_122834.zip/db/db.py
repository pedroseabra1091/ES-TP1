from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base

databaseurl = 'mysql://estp1:estupido123@mydbinstance.ceh0i2qbswvm.eu-west-1.rds.amazonaws.com:3306/autotrader'
#databaseurl = 'mysql://root:Pergula2010@localhost/autotrader'

engine = create_engine(databaseurl)

Base = declarative_base()

def init_db():
	Base.metadata.create_all(engine)