from application import application 
from db import init_db

init_db()
application.run(debug = True)